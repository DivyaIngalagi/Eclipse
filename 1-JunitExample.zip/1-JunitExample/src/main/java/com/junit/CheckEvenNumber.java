package com.junit;

import java.util.function.BooleanSupplier;

public class CheckEvenNumber {

	public static BooleanSupplier isEven(int number) {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.testProduct;

import java.util.List;

public interface ProductService {

	public List<Product> getAllProduct();
}

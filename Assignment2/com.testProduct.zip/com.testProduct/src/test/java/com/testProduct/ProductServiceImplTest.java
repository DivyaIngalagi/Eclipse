package com.testProduct;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

class ProductServiceImplTest {

//	@Test
//	void testProductServiceImpl_Lessthan500() {
//		ProductService prodserv = mock(ProductService.class);
//		List<Product> prodlist = Arrays.asList(new Product(1,"Mobile",15555.00),new Product(2,"Laptop",35555.00),new Product(3,"Charger",400.00),new Product(4,"Pen",500.00),new Product(5,"Glasses",355.00));
//		
//		when(prodserv.getAllProduct()).thenReturn(prodlist);
//		
//		ProductServiceImpl prodServiceImpl=new ProductServiceImpl(prodserv);
//		
//		List<Product>  prod = prodServiceImpl.fetchAllProduct();
//		
//		assertEquals(3, prod.size());
//	}
	
	@Test()
	void testProductServiceImpl_Morethan500() {
		ProductService prodserv = mock(ProductService.class);
		List<Product> prodlist = Arrays.asList(new Product(1,"Mobile",155.00),new Product(2,"Laptop",35555.00),new Product(3,"Charger",400.00),new Product(4,"Pen",500.00),new Product(5,"Glasses",355.00));
		
		when(prodserv.getAllProduct().stream().filter(p->p.getPcost()>500)).thenThrow(new RuntimeException("product price is greated than 500"));
		System.out.println(prodserv.getAllProduct().get(0).getPcost());
		System.out.println(prodlist.get(0));
		
	}
//	@Test
//	void testProductServiceImpl_EqualToZero() {
//		ProductService prodserv = mock(ProductService.class);
//		List<Product> prodlist = Arrays.asList();
//		
//		when(prodserv.getAllProduct()).thenReturn(prodlist);
//		
//		ProductServiceImpl prodServiceImpl=new ProductServiceImpl(prodserv);
//		
//		List<Product>  prod = prodServiceImpl.fetchAllProduct();
//		
//		assertEquals(0, prod.size());
//	}
}

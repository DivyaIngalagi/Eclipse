package ispbank;

public class InsufficientFundsException extends RuntimeException{

}

package ispbank;

//Creational Design Pattern
//Static Factory Object
public class Banker {

	private Banker() {}
	
	public static Account openSavingsAccount() {
		return new SavingsAccount();
	}
	
	public static Account openCurrentAccount() {
		return new CurrentAccount();
	}
}


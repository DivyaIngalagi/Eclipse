package ispbank;

public interface Profitable {

	float MIN_RATE = 4.5f;
	double addInterest(int months);
}

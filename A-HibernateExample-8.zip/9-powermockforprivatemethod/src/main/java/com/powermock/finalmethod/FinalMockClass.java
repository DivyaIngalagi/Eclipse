package com.powermock.finalmethod;
public class FinalMockClass {  
  
    public final String getMessage(String message) {  
        return message;  
    }  
 }  
package com.testConstructor;

public class Constructorm {
	private ConstructorCall cc;
	public void getValue(){
    	this.cc= new ConstructorCall();
//        return cc.getText();
    }
}

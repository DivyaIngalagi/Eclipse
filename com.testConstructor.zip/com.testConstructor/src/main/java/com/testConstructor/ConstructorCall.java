package com.testConstructor;

public class ConstructorCall {
	 public String getText() {
	        return "Fail";
	    }
}


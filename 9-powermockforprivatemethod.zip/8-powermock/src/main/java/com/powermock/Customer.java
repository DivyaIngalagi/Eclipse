package com.powermock;

public class Customer {

	public static String sendMsg(String msg) {
		return msg;
	}

	
}

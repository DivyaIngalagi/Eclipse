package com.spy;

public class MyCal {

	public int multiply(int x, int y)
	{
		return x*y;
	}
	
	public int add(int x, int y)
	{
		return x+y;
	}
}

package com.junit;

public class StringReverse {

	public String checkStringReverseMethod(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.junit;

public class CheckEvenNumber {

}

package com.junit;

public class ParameterizedTestExample2 {

}

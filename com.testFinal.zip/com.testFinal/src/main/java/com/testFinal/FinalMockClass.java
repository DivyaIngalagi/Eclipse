package com.testFinal;


	public class FinalMockClass {  
		  
	    public final String getMessage(String message) {  
	        return message;  
	    }  
	 
	
}

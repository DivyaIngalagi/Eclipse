package com.mock;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

class UserServiceImplTest {

	@Test
	public void usingStub() {
     UserService userService=new UserServiceStub();
     UserServiceImpl userServiceImpl=new UserServiceImpl(userService);
     
    List<String>  user=userServiceImpl.retrieveFilteredUser("Bhawana");
     
     
     assertEquals(4, user.size());
     
	
	}

}

package com.powermock;

public class Bike {
	
	 public final String finalMethod(String message) {  
	        return message;  
	    }  
}

